public class Utama {
    public static void main(String[] args) {
// membuat objek Shape dari class Rectangle
        Shape rect = new Rectangle(25, 40);
// membuat objek Shape dari class Circle
        Shape circ = new Circle(21);
        // membuat objek Shape dari class Triangle
        Shape tria = new Triangle(14, 20);
        /* memanggil method draw */
        rect.draw();
        circ.draw();
        tria.draw();
        System.out.println("Luas Lingkaran: " + circ.getAreas());
        System.out.println("Luas Persegi Panjang: " + rect.getAreas());
        System.out.println("Luas Segitiga: " + tria.getAreas());
    }
}